# Retrospective A

## Date: 21/10/2020

## Time: 17:00

## Team Members Present:
* Kaiqi Liang
* William Huang
* Tony Lu
* Richard Wang


| Last retrospective's To Try | What went well | What didn't go so well | To Try |
| - | - | - | - |
| First sprint so N/A | Met sprint goal, finished every user stories in sprint 1 in time | Duplicated work (Richard made register and login forms when they're already being made) | 1. Check Jira before starting a new task and make sure it is not in the `IN PROGRESS` or `DONE` list <br> 2. Update Jira when starting a task so that other members can see it <br><br> (Richard is assigned to enforce this to make up for his mistake) |
|| Started front-end early | Hard to organise meetings, meetings always pushed back | Introduce services like when2meet (William is assigned to start a when2meet schedule and better organise meetings) |