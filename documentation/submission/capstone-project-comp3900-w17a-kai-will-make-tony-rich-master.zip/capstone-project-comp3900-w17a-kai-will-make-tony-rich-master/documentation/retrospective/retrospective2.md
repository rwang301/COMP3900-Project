# Retrospective B

## Date: 11/11/2020

## Time: 15:00

## Team Members Present:
* Kaiqi Liang
* William Huang
* Tony Lu
* Richard Wang


| Last retrospectives to try| What went well | What didn't go so well | To Try |
| - | - | - | - |
| 1. Check Jira before starting a new task and make sure it is not in the `IN PROGRESS` or `DONE` list <br> 2. Update Jira when starting a task so that other members can see it <br><br> (Richard is assigned to enforce this to make up for his mistake) <br> <br> Update: Richard did what he was told and it improved our efficiency | What we did complete was of high quality and worked as expected | Did not finish sprint |Improve our planning and understanding of problem domain so we can start earlier next time |
|Introduce services like when2meet (William is assigned to start a when2meet schedule and better organise meetings) <br> <br> Update: William set up a when2meet and we organised meetings through it, helping us find common times| Evolved novelty idea so it could better reflect our initial goal of helping jobseekers find the best possible matches ||  |